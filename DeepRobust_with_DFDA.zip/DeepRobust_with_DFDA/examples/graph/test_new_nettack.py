import torch
import numpy as np
import torch.nn.functional as F
import torch.optim as optim
from deeprobust.graph.defense import GCN
from deeprobust.graph.defense import GCNJaccard
from deeprobust.graph.defense import GCNSVD
from deeprobust.graph.targeted_attack import Nettack
from deeprobust.graph.utils import *
from deeprobust.graph.data import Dataset
import argparse
from tqdm import tqdm
import copy
import random

#参数方面
parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=15, help='Random seed.')
parser.add_argument('--dataset', type=str, default='citeseer', choices=['cora', 'cora_ml', 'citeseer', 'polblogs', 'pubmed'], help='dataset')
parser.add_argument('--ptb_rate', type=float, default=0.05,  help='pertubation rate')
parser.add_argument('--direct', type=int, default=1,  help='direct attack or indirect attack')
parser.add_argument('--influncer_num', type=int, default=1,  help='influncer num')
parser.add_argument('--filename',type=str,default='temp',help='test data file name')
parser.add_argument('--avgtimes',type=int,default=3,help='experiment times')
parser.add_argument('--model', type=str, default='GCN',choices=['GCN','GCN-jaccard','GCN-SVD'], help='defense model')
parser.add_argument('--pertn', type=int, default=5, help='number of perturbations')
args = parser.parse_args()

txtname='txt_data/' + args.filename + '.txt'

#GPU加速
args.cuda = torch.cuda.is_available()
print('cuda: %s' % args.cuda)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

#设置随机种子，使得结果是确定的
np.random.seed(args.seed)
torch.manual_seed(args.seed)
if args.cuda:
    torch.cuda.manual_seed(args.seed)

#加载数据集
data = Dataset(root='/tmp/', name=args.dataset)
adj, features, labels = data.adj, data.features, data.labels #边，特征，标签
print(adj.shape, features.shape, data.labels)

idx_train, idx_val, idx_test = data.idx_train, data.idx_val, data.idx_test #划分训练集，验证集和测试集

idx_unlabeled = np.union1d(idx_val, idx_test)#得出无标签节点集=验证集+测试集

#设置代理模型：GCN，无relu，无偏置，无dropout
surrogate = GCNSVD(nfeat=features.shape[1], nclass=labels.max().item()+1,
                nhid=16, dropout=0, with_relu=False, with_bias=False, device=device)

surrogate = surrogate.to(device) #代理模型上GPU
surrogate.fit(features, adj, labels, idx_train, idx_val, patience=30) #填入数据

#设置最终攻击的模型并进行查询，获取用于评估攻击效果的干净图测试集预测输出
victim = GCNSVD(nfeat=features.shape[1],
                  nhid=16,
                  nclass=labels.max().item() + 1,
                  dropout=0.5, device=device)
victim = victim.to(device)
victim.fit(features, adj, labels, idx_train, idx_val, patience=30)
victim.eval()

victim_output=victim.predict()


#选择目标节点
target_node = 0
assert target_node in idx_unlabeled #保证选择的目标节点在无标签节点集中

#设置攻击算法：Nettack
model = Nettack(surrogate, nnodes=adj.shape[0], attack_structure=True, attack_features=False, device=device)
model = model.to(device)

#随机节点选择算法：选出num个至少有influncer_num个邻居的节点作为目标节点
def random_select_nodes_indirect(num):
    unlabel=copy.deepcopy(idx_unlabeled)
    random.shuffle(unlabel)
    candidate=0
    attack_set=[]
    print("选择", num, "个节点")
    for i in range(num):
        while True:
            influencer_num=0
            influencers=[]
            for j in range(adj.shape[0]):
                if adj[unlabel[candidate], j] == 1:
                    influencer_num+=1
                    influencers.append(j)

            print("第",candidate,"节点","ID:",unlabel[candidate])
            print("influncer_num:",influencer_num, influencers)

            if influencer_num>=args.influncer_num:
                attack_set.append(unlabel[candidate])
                print("success")
                candidate += 1
                break
            print("fail")
            candidate+=1

    print(attack_set)
    return attack_set

def random_select_nodes(num):
    unlabel=copy.deepcopy(idx_unlabeled)
    random.shuffle(unlabel)
    print(unlabel[:num])
    print(unlabel[:num].shape[0])
    return unlabel[:num]

def main():
    degrees = adj.sum(0).A1 #每行求和并展平？
    # How many perturbations to perform. Default: Degree of the node
    n_perturbations = int(degrees[target_node])

    # direct attack 直接攻击
    model.attack(features, adj, labels, target_node, n_perturbations)

    # indirect attack/ influencer attack 间接攻击/影响者攻击
    # model.attack(features, adj, labels, target_node, n_perturbations, direct=False, n_influencers=5)
    modified_adj = model.modified_adj #扰动后的邻接矩阵
    modified_features = model.modified_features #扰动后的特征矩阵
    print(model.structure_perturbations) #输出结构扰动

    #整体测试
    #输出原数据上的GCN测试结果
    print('=== testing GCN on original(clean) graph ===')
    test(adj, features, target_node)
    #输出扰动后数据上的GCN测试结果
    print('=== testing GCN on perturbed graph ===')
    test(modified_adj, modified_features, target_node)

#测试GCN整体精度
def test(adj, features, target_node):
    ''' test on GCN '''
    #真实环境下GCN
    gcn = GCNSVD(nfeat=features.shape[1],
              nhid=16,
              nclass=labels.max().item() + 1,
              dropout=0.5, device=device)

    gcn = gcn.to(device)
    gcn.fit(features, adj, labels, idx_train, idx_val, patience=30)
    gcn.eval()#进入evaluation模式

    #输出目标节点的各类别的指数概率
    output = gcn.predict()
    probs = torch.exp(output[[target_node]])[0]
    print('Target node probs: {}'.format(probs.detach().cpu().numpy()))
    acc_test = accuracy(output[idx_test], labels[idx_test])

    print("Overall test set results:",
          "accuracy= {:.4f}".format(acc_test.item()))

    return acc_test.item()

#多节点投毒攻击
def multi_test_poison():
    # test on 40 nodes on poisoining attack
    cnt = 0
    degrees = adj.sum(0).A1
    node_list = random_select_nodes(30)
    num = len(node_list)
    print('=== [Poisoning] Attacking %s nodes respectively ===' % num)
    for target_node in tqdm(node_list):
        n_perturbations = args.pertn
        model = Nettack(surrogate, nnodes=adj.shape[0], attack_structure=True, attack_features=False, device=device)
        model = model.to(device)
        model.attack(features, adj, labels, target_node, n_perturbations, direct=args.direct, n_influencers=args.influncer_num, verbose=True)
        modified_adj = model.modified_adj
        modified_features = model.modified_features
        acc = single_test(modified_adj, modified_features, target_node)#调用单节点测试
        if acc == 0:
            cnt += 1
    print('misclassification rate : %s' % (cnt/num))
    return cnt/num

#单节点测试
def single_test(adj, features, target_node, gcn=None):
    if gcn is None:
        # test on GCN (poisoning attack)
        gcn = GCNSVD(nfeat=features.shape[1],
                  nhid=16,
                  nclass=labels.max().item() + 1,
                  dropout=0.5, device=device)

        gcn = gcn.to(device)

        gcn.fit(features, adj, labels, idx_train, idx_val, patience=30)
        gcn.eval()
        output = gcn.predict()
    else:
        # test on GCN (evasion attack)
        output = gcn.predict(features, adj)


    # acc_test = accuracy(output[[target_node]], labels[target_node])
    acc_test = (output.argmax(1)[target_node] == victim_output.argmax(1)[target_node])
    return acc_test.item()

#多节点逃逸攻击
def multi_test_evasion():
    # test on 40 nodes on evasion attack
    target_gcn = GCNSVD(nfeat=features.shape[1],
              nhid=16,
              nclass=labels.max().item() + 1,
              dropout=0.5, device=device)

    target_gcn = target_gcn.to(device)

    target_gcn.fit(features, adj, labels, idx_train, idx_val, patience=30)

    cnt = 0
    degrees = adj.sum(0).A1
    node_list = random_select_nodes(50)
    num = len(node_list)

    print('=== [Evasion] Attacking %s nodes respectively ===' % num)
    for target_node in tqdm(node_list):
        n_perturbations = int(degrees[target_node])
        model = Nettack(surrogate, nnodes=adj.shape[0], attack_structure=True, attack_features=False, device=device)
        model = model.to(device)
        model.attack(features, adj, labels, target_node, n_perturbations, verbose=False)
        modified_adj = model.modified_adj
        modified_features = model.modified_features

        acc = single_test(modified_adj, modified_features, target_node, gcn=target_gcn)
        if acc == 0:
            cnt += 1
    print('misclassification rate : %s' % (cnt/num))

if __name__ == '__main__':
    #main()

    record_text = open(txtname, 'a+')
    record_text.write(str(args) + '\n')
    record_text.close()

    sr_list = []
    for i in range(args.avgtimes):
        sr= multi_test_poison()  # 多节点投毒攻击
        sr_list.append(sr)
        record_text = open(txtname, 'a+')
        record_text.write('sr:' + str(sr) + '\n')
        record_text.close()

    ave_sr = np.mean(sr_list)
    std_sr = np.std(sr_list, ddof=1)

    record_text = open(txtname, 'a+')
    record_text.write('average/std sr:' + str(ave_sr) + '+/-' + str(std_sr) + '\n')
    record_text.close()


    #multi_test_evasion()


