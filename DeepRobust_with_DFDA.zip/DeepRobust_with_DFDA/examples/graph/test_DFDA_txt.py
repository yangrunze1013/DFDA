'''
    DFDA experiment running file
'''

import torch
import numpy as np
import torch.nn.functional as F
import torch.optim as optim
from deeprobust.graph.defense import *
from deeprobust.graph.targeted_attack import dfda
from deeprobust.graph.utils import *
from deeprobust.graph.data import Dataset
import argparse
from tqdm import tqdm
import random
import copy
import matplotlib.pyplot as plt

parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=17, help='Random seed.')
parser.add_argument('--dataset', type=str, default='citeseer', choices=['cora', 'cora_ml', 'citeseer', 'polblogs', 'pubmed'], help='dataset')
parser.add_argument('--target', type=int, default=0, help='target node ID')
parser.add_argument('--type', type=str, default='structure',choices=['structure','feature','both'], help='attack type')
parser.add_argument('--model', type=str, default='GCN',choices=['GCN','GCN-jaccard','GCN-SVD'], help='defense model')
parser.add_argument('--pertn', type=int, default=5, help='constraint size')
parser.add_argument('--budget', type=int, default=100, help='resurce budget')
parser.add_argument('--multitest', type=str, default='yes',choices=['no','yes'], help='whether to test a set of nodes')
parser.add_argument('--situation', type=str, default='poison',choices=['poison','evasion'], help='attack scenario: whether to perform poison attack or evasion attack')
parser.add_argument('--ntarget', type=int, default=50, help='number of attack nodes in the target set')
parser.add_argument('--mutator', type=str, default='DFGA',choices=['DFGA','DE','TPDE','RIDE','OPO','DOPO','RND'], help='DFOer: Derivetive-Free Optimizer')
parser.add_argument('--filename',type=str,default='temp',help='save data file name')
parser.add_argument('--avgtimes',type=int,default=5,help='experiment times')
args = parser.parse_args()

print(str(args))

txtname='txt_data/' + args.filename + '.txt'

args.cuda = torch.cuda.is_available()
print('cuda: %s' % args.cuda)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

np.random.seed(args.seed)
torch.manual_seed(args.seed)
if args.cuda:
    torch.cuda.manual_seed(args.seed)

print("-------------loading dataset--------------")
data = Dataset(root='/tmp/', name=args.dataset)
adj, features, labels = data.adj, data.features, data.labels
idx_train, idx_val, idx_test = data.idx_train, data.idx_val, data.idx_test
idx_unlabeled = np.union1d(idx_val, idx_test)
np.set_printoptions(threshold=20)

real_model=None
if args.model=='GCN':
    real_model = GCN(nfeat=features.shape[1],
                  nhid=16,
                  nclass=labels.max().item() + 1,
                  dropout=0.5, device=device)
elif args.model=='GCN-jaccard':
    real_model = GCNJaccard(nfeat=features.shape[1],
                     nhid=16,
                     nclass=labels.max().item() + 1,
                     dropout=0.5, device=device)
elif args.model=='GCN-SVD':
    real_model = GCNSVD(nfeat=features.shape[1],
                     nhid=16,
                     nclass=labels.max().item() + 1,
                     dropout=0.5, device=device)

real_model = real_model.to(device)
real_model.fit(features, adj, labels, idx_train, idx_val, patience=30)
clean_output = real_model.predict(features,adj)
clean_probs = torch.exp(clean_output).detach().cpu().numpy()

target_node = args.target
assert target_node in idx_unlabeled

att_str=True
att_fea=True
if args.type=='structure':
    att_fea = False
elif args.type=='feature':
    att_str=False
elif args.type=='both':
    pass

model = dfda.dfda(real_model, nnodes=adj.shape[0], attack_structure=att_str, attack_features=att_fea, device=device)
model = model.to(device)

def main():
    print("-----------start single-node attack------------")
    model.attack(features, adj, target_node, n_perturbations=args.pertn, budget=args.budget)
    modified_adj = model.modified_adj
    modified_features = model.modified_features
    print("-------------attack over--------------")
    print()
    print('-----------test GCN on clean graph----------')
    param_dict = {
        'most_likely_class': 0,
        'max_prob': 0,
        'clean': True,
    }
    clean_pprobs=test(adj, features, target_node, param_dict)
    print("most probable class：", param_dict['most_likely_class'])
    print("largest probability：%.4f" % param_dict['max_prob'])

    print('-----------test GCN on perturbed graph-----------')
    param_dict_pert = {
        'most_likely_class': 0,
        'pre_most_likely_class':param_dict['most_likely_class'],
        'after_pert_prob': 0,
        'clean': False,
    }
    pert_pprobs=test(modified_adj, modified_features, target_node, param_dict_pert)
    print("most probable class：", param_dict_pert['most_likely_class'])
    print("original class probability：%.4f" % param_dict_pert['after_pert_prob'])

    print("----------------attack results-----------------")
    score=100*(param_dict['max_prob']-param_dict_pert['after_pert_prob'])/param_dict['max_prob']
    if param_dict_pert['pre_most_likely_class'] != param_dict_pert['most_likely_class']:
        if model.best_wrong_class==param_dict_pert['most_likely_class']:
            print("Misleading attack success，class changed from",param_dict_pert['pre_most_likely_class'],"to target class",param_dict_pert['most_likely_class'])
        else:
            print("Attack success, class changed from", param_dict_pert['pre_most_likely_class'], "to", param_dict_pert['most_likely_class'])
        print("original class probability decline from",param_dict['max_prob'],"to",param_dict_pert['after_pert_prob'])
    else:
        print("attack failed")

    margin=param_dict_pert['after_pert_prob']-param_dict['max_prob']
    print("classification margin：", margin)

    plt.figure(1)
    ax1 = plt.subplot(1, 2, 1)
    ax2 = plt.subplot(1, 2, 2)
    plt.ylim(0, 1)
    plt.xticks(range(len(clean_pprobs)))

    plt.sca(ax1)
    plt.title('No.' + str(target_node) + ' node clean graph probs')
    plt.bar(range(len(clean_pprobs)), clean_pprobs)

    plt.sca(ax2)
    plt.title('No.' + str(target_node) + ' node pert graph probs')
    plt.bar(range(len(pert_pprobs)), pert_pprobs)

    plt.show()

    return margin


def test(adj, features, target_node, param_dict):

    gcn=None
    if args.model == 'GCN':
        gcn = GCN(nfeat=features.shape[1],
                nhid=16,
                nclass=labels.max().item() + 1,
                dropout=0.5, device=device)
    elif args.model == 'GCN-jaccard':
        gcn = GCNJaccard(nfeat=features.shape[1],
                  nhid=16,
                  nclass=labels.max().item() + 1,
                  dropout=0.5, device=device)
    elif args.model == 'GCN-SVD':
        gcn = GCNSVD(nfeat=features.shape[1],
                  nhid=16,
                  nclass=labels.max().item() + 1,
                  dropout=0.5, device=device)
    gcn = gcn.to(device)
    gcn.fit(features, adj, labels, idx_train, idx_val, patience=30)
    gcn.eval()

    output = gcn.predict()
    probs = torch.exp(output[[target_node]])[0]
    pprobs = probs.detach().cpu().numpy()
    print('classification probability vector of ：{}'.format(pprobs))
    param_dict['most_likely_class'] = np.argmax(pprobs)
    if param_dict['clean']:
        param_dict['max_prob']=pprobs[param_dict['most_likely_class']]
    else:
        param_dict['after_pert_prob']=pprobs[param_dict['pre_most_likely_class']]


    acc_test = accuracy(output[idx_test], labels[idx_test])


    return pprobs


def random_select_nodes(num):
    unlabel=copy.deepcopy(idx_unlabeled)
    random.shuffle(unlabel)
    print(unlabel[:num])
    print(unlabel[:num].shape[0])
    return unlabel[:num]

#poisoning attack
def multi_test_poison():
    node_list = random_select_nodes(args.ntarget)
    num = len(node_list)

    gcn = None
    if args.model == 'GCN':
        gcn = GCN(nfeat=features.shape[1],
                  nhid=16,
                  nclass=labels.max().item() + 1,
                  dropout=0.5, device=device)
    elif args.model == 'GCN-jaccard':
        gcn = GCNJaccard(nfeat=features.shape[1],
                         nhid=16,
                         nclass=labels.max().item() + 1,
                         dropout=0.5, device=device)
    elif args.model == 'GCN-SVD':
        gcn = GCNSVD(nfeat=features.shape[1],
                     nhid=16,
                     nclass=labels.max().item() + 1,
                     dropout=0.5, device=device)
    gcn = gcn.to(device)
    gcn.fit(features, adj, labels, idx_train, idx_val, patience=30)
    gcn.eval()
    output = gcn.predict()
    probs = torch.exp(output).detach().cpu().numpy()


    print('--------------[poisoning] attack on %s nodes seperately------------' % num)
    count=0
    success=0
    perfect=0
    for target in tqdm(node_list):
        count += 1
        print()
        print("-----------the", count, "th node，ID：", target,"---------")
        model = dfda.dfda(gcn, nnodes=adj.shape[0], attack_structure=att_str, attack_features=att_fea, device=device)
        model = model.to(device)
        model.attack(features, adj, target, n_perturbations=args.pertn, budget=args.budget)
        modified_adj = model.modified_adj
        modified_features = model.modified_features
        pert_output = single_test(modified_adj, modified_features)

        print("-----------test GCN on clean graph-----------")
        pprobs = probs[target]

        print(target,'th node class probability vector：{}'.format(pprobs))
        ori_best_class=np.argmax(pprobs)
        print('most probable class：{}'.format(ori_best_class))
        ori_best_prob=pprobs[ori_best_class]
        print('most probability：{}'.format(ori_best_prob))

        print('target class：{}'.format(model.best_wrong_class))
        print("-----------test GCN on perturbed graph-----------")
        pert_probs = torch.exp(pert_output[[target]])[0]
        pert_pprobs = pert_probs.detach().cpu().numpy()
        print(target, 'th node class probability vector after attack：{}'.format(pert_pprobs))
        pert_best_class = np.argmax(pert_pprobs)
        print('current class：{}'.format(pert_best_class))

        print("----------------attack result-----------------")
        score = 100 * (ori_best_prob - pert_pprobs[ori_best_class]) / ori_best_prob
        if ori_best_class != pert_best_class:
            if model.best_wrong_class == pert_best_class:
                print("Misleading attack success，class changed from", ori_best_class, "to the target class", model.best_wrong_class)
                perfect+=1
            else:
                print("Attack success, class changed from", ori_best_class, "to", pert_best_class)
            success+=1
            print("original class probability decline from", ori_best_prob, "to", pert_pprobs[ori_best_class])
        else:
            print("attack failed")

    sr=success/num
    mr=perfect/num

    record_text = open(txtname, 'a+')
    record_text.write('sr:%s\n' % (sr))
    record_text.write('mr:%s\n' % (mr))
    record_text.close()

    print('Success rate (SR) : %s' % (sr))
    print('Misleading rate (MR) : %s' % (mr))

    return sr,mr


def single_test(adj, features, gcn=None):
    if gcn is None:
        # test on GCN (poisoning attack)
        gcn = None
        if args.model == 'GCN':
            gcn = GCN(nfeat=features.shape[1],
                      nhid=16,
                      nclass=labels.max().item() + 1,
                      dropout=0.5, device=device)
        elif args.model == 'GCN-jaccard':
            gcn = GCNJaccard(nfeat=features.shape[1],
                             nhid=16,
                             nclass=labels.max().item() + 1,
                             dropout=0.5, device=device)
        elif args.model == 'GCN-SVD':
            gcn = GCNSVD(nfeat=features.shape[1],
                         nhid=16,
                         nclass=labels.max().item() + 1,
                         dropout=0.5, device=device)
        gcn = gcn.to(device)
        gcn.fit(features, adj, labels, idx_train, idx_val, patience=30)
        gcn.eval()
        output = gcn.predict()
    else:
        # test on GCN (evasion attack)
        output = gcn.predict(features, adj)
    return output

#evasion attack
def multi_test_evasion():
    node_list = random_select_nodes(args.ntarget)
    num = len(node_list)

    gcn = None
    if args.model == 'GCN':
        gcn = GCN(nfeat=features.shape[1],
                  nhid=16,
                  nclass=labels.max().item() + 1,
                  dropout=0.5, device=device)
    elif args.model == 'GCN-jaccard':
        gcn = GCNJaccard(nfeat=features.shape[1],
                         nhid=16,
                         nclass=labels.max().item() + 1,
                         dropout=0.5, device=device)
    elif args.model == 'GCN-SVD':
        gcn = GCNSVD(nfeat=features.shape[1],
                     nhid=16,
                     nclass=labels.max().item() + 1,
                     dropout=0.5, device=device)
    gcn = gcn.to(device)
    gcn.fit(features, adj, labels, idx_train, idx_val, patience=30)
    gcn.eval()
    output = gcn.predict()
    probs = torch.exp(output).detach().cpu().numpy()

    print('--------------[evasion] attack on %s nodes seperately------------' % num)
    count = 0
    success = 0
    perfect = 0
    for target in tqdm(node_list):
        count += 1
        print()
        print("-----------the", count, "th node，ID：", target,"---------")
        model = dfda.dfda(gcn, nnodes=adj.shape[0], attack_structure=att_str, attack_features=att_fea, device=device)
        model = model.to(device)
        model.attack(features, adj, target, n_perturbations=args.pertn, budget=args.budget)
        modified_adj = model.modified_adj
        modified_features = model.modified_features
        pert_output = single_test(modified_adj, modified_features, gcn)

        print("-----------test GCN on clean graph-----------")
        pprobs = probs[target]

        print(target, 'th node class probability vector：{}'.format(pprobs))
        ori_best_class = np.argmax(pprobs)
        print('most probable class：{}'.format(ori_best_class))
        ori_best_prob = pprobs[ori_best_class]
        print('most probability：{}'.format(ori_best_prob))

        print('target class：{}'.format(model.best_wrong_class))
        print("-----------test GCN on perturbed graph-----------")
        pert_probs = torch.exp(pert_output[[target]])[0]
        pert_pprobs = pert_probs.detach().cpu().numpy()
        print(target, 'th node class probability vector after attack：{}'.format(pert_pprobs))
        pert_best_class = np.argmax(pert_pprobs)
        print('current class：{}'.format(pert_best_class))

        print("----------------attack result-----------------")
        score = 100 * (ori_best_prob - pert_pprobs[ori_best_class]) / ori_best_prob
        if ori_best_class != pert_best_class:
            if model.best_wrong_class == pert_best_class:
                print("Misleading attack success，class changed from", ori_best_class, "to the target class",
                      model.best_wrong_class)
                perfect += 1
            else:
                print("Attack success, class changed from", ori_best_class, "to", pert_best_class)
            success += 1
            print("original class probability decline from", ori_best_prob, "to", pert_pprobs[ori_best_class])
        else:
            print("attack failed")

    sr = success / num
    mr = perfect / num

    record_text = open(txtname, 'a+')
    record_text.write('sr:%s\n' % (sr))
    record_text.write('mr:%s\n' % (mr))
    record_text.close()

    print('Success rate (SR) : %s' % (sr))
    print('Misleading rate (MR) : %s' % (mr))

    return sr, mr

if __name__ == '__main__':
    if args.multitest=='no':
        print('margin:', main()) #seed=15

    else:
        if args.situation=='poison':
            record_text = open(txtname, 'a+')
            record_text.write(str(args) + '\n')
            record_text.close()

            sr_list=[]
            mr_list=[]
            for i in range(args.avgtimes):

                sr,mr=multi_test_poison()
                sr_list.append(sr)
                mr_list.append(mr)


            ave_sr=np.mean(sr_list)
            ave_mr=np.mean(mr_list)

            std_sr=np.std(sr_list,ddof=1)
            std_mr=np.std(mr_list,ddof=1)

            record_text = open(txtname, 'a+')
            record_text.write('average/std sr:' + str(ave_sr) + '+/-' + str(std_sr) + '\n')
            record_text.write('average/std mr:' + str(ave_mr) + '+/-' + str(std_mr) + '\n')
            record_text.close()

        elif args.situation=='evasion':
            print(multi_test_evasion())

