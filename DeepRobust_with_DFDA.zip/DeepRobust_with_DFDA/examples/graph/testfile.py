import h5py
import numpy as np
import os
#if os.path.exists('./test_data/test_data5.hdf5'):

f=h5py.File("./test_data/test_data4.hdf5","w")
#deset1是数据集的name，（20,）代表数据集的shape，i代表的是数据集的元素类型
data=np.array([[1,2,3,4],[1,2,3,4]])
data2=[2,3,4,5]
dict={'a':123}
g1=f.create_group('group1')
d1=f.create_dataset("dataset1", data=data)
d2=g1.create_dataset('dataset2',data=data2)
print(d1[:])
f.close()

ff=h5py.File("./test_data/b100n50poistruct.hdf5","r")
print(ff.attrs['args'])
for group in ff.keys():
    print(group)
    if group=='all_nodes':
        print(ff[group + '/clean_output_probs'][:])
        continue
    print(ff[group + '/pert_prob'][:])
    print(ff[group + '/pert_struct_vector'][:])
    print(ff[group + '/pert_feat_vector'][:])
ff.close()