import matplotlib.pyplot as plt
import numpy as np
#beta = ['10','25','50','100','200']
beta = [10, 25, 50, 100, 200]
sr = [0.68,0.82,0.80,0.94,0.94]
mr = [0.54,0.72,0.72,0.86,0.86]

l1,=plt.plot(beta, sr, marker='o', ms='6', color='red', linewidth=1.0, linestyle='-')
l2,=plt.plot(beta, mr, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='--')

plt.xlabel('Resource Budget')
plt.ylabel('Successful/Misleading Rate')

plt.legend(handles=[l1,l2],labels=['SR','MR'],loc='best')
plt.show()