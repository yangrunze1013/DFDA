import matplotlib.pyplot as plt
import numpy as np

delta = ['2', '4', '6']
sr_GCN = [0.46,0.86,0.86]
mr_GCN = [0.46,0.80,0.83]

sr_Jac = [0.63,0.83,0.93]
mr_Jac = [0.53,0.76,0.83]

sr_SVD = [0.63,0.80,0.90]
mr_SVD = [0.60,0.73,0.76]

l1,=plt.plot(delta, sr_GCN, marker='o', ms='6', color='red', linewidth=1.0, linestyle='-')
l2,=plt.plot(delta, mr_GCN, marker='o', ms='6', color='red', linewidth=1.0, linestyle='--')

l3,=plt.plot(delta, sr_Jac, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='-')
l4,=plt.plot(delta, mr_Jac, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='--')

l5,=plt.plot(delta, sr_SVD, marker='*', ms='8', color='green', linewidth=1.0, linestyle='-')
l6,=plt.plot(delta, mr_SVD, marker='*', ms='8', color='green', linewidth=1.0, linestyle='--')

plt.xlabel('Perturbation Constraint')
plt.ylabel('Successful Rate')

plt.legend(handles=[l1,l2,l3,l4,l5,l6],labels=['SR 2-layer GCN','MR 2-layer GCN','SR GCN-Jaccard','MR GCN-Jaccard','SR GCN-SVD','MR GCN-SVD'],loc='upper left')
plt.show()