import matplotlib.pyplot as plt
import numpy as np

delta = ['2', '4', '6', '8']
DFDA_GCN = [70.0,83.3,88.7,98.0]
Nettack_GCN = [53.3,73.3,68.0,74.0]

DFDA_Jac = [54.7,72.0,81.3,88.0]
Nettack_Jac = [39.3,61.3,70.0,77.3]

DFDA_SVD = [41.3,65.3,73.3,78.7]
Nettack_SVD = [32.0,54.7,68.7,72.0]

l1,=plt.plot(delta, DFDA_GCN, marker='o', ms='6', color='red', linewidth=1.0, linestyle='-')
l2,=plt.plot(delta, Nettack_GCN, marker='o', ms='6', color='red', linewidth=1.0, linestyle='--')

l3,=plt.plot(delta, DFDA_Jac, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='-')
l4,=plt.plot(delta, Nettack_Jac, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='--')

l5,=plt.plot(delta, DFDA_SVD, marker='*', ms='8', color='green', linewidth=1.0, linestyle='-')
l6,=plt.plot(delta, Nettack_SVD, marker='*', ms='8', color='green', linewidth=1.0, linestyle='--')

plt.xlabel('Perturbation Constraint')
plt.ylabel('Success Rate')

plt.legend(handles=[l1,l2,l3,l4,l5,l6],labels=['DFDA-GCN','Nettack-GCN','DFDA-Jaccard','Nettack-Jaccard','DFDA-SVD','Nettack-SVD'],loc='upper left')
plt.show()

