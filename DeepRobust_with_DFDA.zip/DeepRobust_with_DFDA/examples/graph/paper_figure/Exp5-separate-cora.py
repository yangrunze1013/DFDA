import matplotlib.pyplot as plt
import numpy as np

delta = ['2', '4', '6', '8']
DFDA_GCN = [62.7,85.3,95.3,95.3]
Nettack_GCN = [69.3,78.7,88.0,85.3]

l1,=plt.plot(delta, DFDA_GCN, marker='o', ms='6', color='red', linewidth=1.0, linestyle='-')
l2,=plt.plot(delta, Nettack_GCN, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='-')

plt.xlabel('Perturbation Constraint')
plt.ylabel('Average Success Rate / %')

plt.legend(handles=[l1,l2],labels=['DFDA','Nettack'],loc='upper left')
plt.show()


DFDA_Jac = [39.3,58.0,73.3,80.0]
Nettack_Jac = [42.7,61.3,72.0,79.3]

l3,=plt.plot(delta, DFDA_Jac, marker='o', ms='6', color='red', linewidth=1.0, linestyle='-')
l4,=plt.plot(delta, Nettack_Jac, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='-')

plt.xlabel('Perturbation Constraint')
plt.ylabel('Average Success Rate / %')

plt.legend(handles=[l3,l4],labels=['DFDA','Nettack'],loc='upper left')
plt.show()

DFDA_SVD = [20.0,48.6,68.0,67.3]
Nettack_SVD = [10.0,22.7,42.7,56.0]


l5,=plt.plot(delta, DFDA_SVD, marker='o', ms='6', color='red', linewidth=1.0, linestyle='-')
l6,=plt.plot(delta, Nettack_SVD, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='-')

plt.xlabel('Perturbation Constraint')
plt.ylabel('Average Success Rate / %')

plt.legend(handles=[l5,l6],labels=['DFDA','Nettack'],loc='upper left')
plt.show()