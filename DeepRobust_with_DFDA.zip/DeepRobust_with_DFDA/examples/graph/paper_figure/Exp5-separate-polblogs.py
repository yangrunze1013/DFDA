import matplotlib.pyplot as plt
import numpy as np

delta = ['2', '4', '6', '8']
DFDA_GCN = [51.3,56.7,69.3,70.0]
Nettack_GCN = [28.0,54.0,58.0,64.7]

l1,=plt.plot(delta, DFDA_GCN, marker='o', ms='6', color='red', linewidth=1.0, linestyle='-')
l2,=plt.plot(delta, Nettack_GCN, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='-')

plt.xlabel('Perturbation Constraint')
plt.ylabel('Average Success Rate / %')

plt.legend(handles=[l1,l2],labels=['DFDA','Nettack'],loc='upper left')
plt.show()

DFDA_Jac = [41.3,44.7,41.3,39.3]
Nettack_Jac = [31.3,30.0,32.0,35.3]

l3,=plt.plot(delta, DFDA_Jac, marker='o', ms='6', color='red', linewidth=1.0, linestyle='-')
l4,=plt.plot(delta, Nettack_Jac, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='-')

plt.xlabel('Perturbation Constraint')
plt.ylabel('Average Success Rate / %')

plt.legend(handles=[l3,l4],labels=['DFDA','Nettack'],loc='upper left')
plt.show()

DFDA_SVD = [7.3,13.3,23.3,34.6]
Nettack_SVD = [1.3,6.7,14.0,31.3]


l5,=plt.plot(delta, DFDA_SVD, marker='o', ms='6', color='red', linewidth=1.0, linestyle='-')
l6,=plt.plot(delta, Nettack_SVD, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='-')

plt.xlabel('Perturbation Constraint')
plt.ylabel('Average Success Rate / %')

plt.legend(handles=[l5,l6],labels=['DFDA','Nettack'],loc='upper left')
plt.show()