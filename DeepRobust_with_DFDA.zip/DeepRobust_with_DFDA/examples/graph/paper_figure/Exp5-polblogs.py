import matplotlib.pyplot as plt
import numpy as np

delta = ['2', '4', '6']
DFDA_GCN = [0.50,0.70,0.63]
Nettack_GCN = [0.32,0.58,0.62]

DFDA_Jac = [0.03,0.20,0.16]
Nettack_Jac = [0.36,0.23,0.46]

DFDA_SVD = [0.16,0.06,0.20]
Nettack_SVD = [0.06,0.23,0.26]

l1,=plt.plot(delta, DFDA_GCN, marker='o', ms='6', color='red', linewidth=1.0, linestyle='-')
l2,=plt.plot(delta, Nettack_GCN, marker='o', ms='6', color='red', linewidth=1.0, linestyle='--')

l3,=plt.plot(delta, DFDA_Jac, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='-')
l4,=plt.plot(delta, Nettack_Jac, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='--')

l5,=plt.plot(delta, DFDA_SVD, marker='*', ms='8', color='green', linewidth=1.0, linestyle='-')
l6,=plt.plot(delta, Nettack_SVD, marker='*', ms='8', color='green', linewidth=1.0, linestyle='--')

plt.xlabel('Perturbation Constraint')
plt.ylabel('Successful Rate')

plt.legend(handles=[l1,l2,l3,l4,l5,l6],labels=['DFDA-GCN','Nettack-GCN','DFDA-Jaccard','Nettack-Jaccard','DFDA-SVD','Nettack-SVD'],loc='upper left')
plt.show()