import matplotlib.pyplot as plt
import numpy as np

delta = ['2', '4', '6', '8', '10']
sr_struct = [0.60,0.88,0.96,0.92,0.98]
mr_struct = [0.56,0.84,0.86,0.80,0.92]

sr_feat = [0.10, 0.14, 0.22, 0.24, 0.30]
mr_feat = [0.08, 0.14, 0.20, 0.24, 0.30]

sr_both = [0.70, 0.92, 0.94, 0.98, 0.98]
mr_both = [0.68, 0.88, 0.94, 0.80, 0.94]

l1,=plt.plot(delta, sr_struct, marker='o', ms='6', color='red', linewidth=1.0, linestyle='-')
#l2,=plt.plot(delta, mr_struct, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='-')

l3,=plt.plot(delta, sr_feat, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='-')
#l4,=plt.plot(delta, mr_feat, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='-')

l5,=plt.plot(delta, sr_both, marker='*', ms='8', color='green', linewidth=1.0, linestyle='-')
#l6,=plt.plot(delta, mr_both, marker='^', ms='6', color='blue', linewidth=1.0, linestyle='-')

plt.xlabel('Perturbation Constraint')
plt.ylabel('Successful Rate')

plt.legend(handles=[l1,l3,l5],labels=['Structure','Feature','Both'],loc='best')
plt.show()