import deeprobust.image.netmodels.train_model as trainmodel
trainmodel.train('CNN','MNIST','cuda', 20)
