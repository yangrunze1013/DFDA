import torch
import copy

def dfda_function(arraya,arrayx,A,X,target_node,attack_stucture,attack_features,best_wrong_class,target_model,target_node_label):
    # A=copy.deepcopy(A_)
    # X=copy.deepcopy(X_)

    #perturbation
    if attack_stucture:
        pert_edges = []
        for _ in arraya:
            pert_edges.append((target_node, _))
        for edge in pert_edges:
            A[edge]=A[edge[::-1]]=1-A[edge]

    if attack_features:
        pert_features = []
        for _ in arrayx:
            pert_features.append((target_node, _))
        for feature in pert_features:
             X[feature] = 1 - X[feature]



    output = target_model.predict(X,A)
    probs = torch.exp(output[[target_node]])[0]
    pprobs = probs.detach().cpu().numpy()
    loss = pprobs[target_node_label] - pprobs[best_wrong_class]

    #inverse perturbation
    if attack_stucture:
        pert_edges = []
        for _ in arraya:
            pert_edges.append((target_node, _))
        for edge in pert_edges:
            A[edge] = A[edge[::-1]] = 1 - A[edge]

    if attack_features:
        pert_features = []
        for _ in arrayx:
            pert_features.append((target_node, _))
        for feature in pert_features:
            X[feature] = 1 - X[feature]

    return loss
