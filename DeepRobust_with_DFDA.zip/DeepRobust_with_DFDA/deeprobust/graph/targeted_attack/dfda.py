'''
    Derivative-Free Direct Attack
'''

import torch
from deeprobust.graph.targeted_attack import BaseAttack
from deeprobust.graph import utils
import nevergrad as ng
from deeprobust.graph.targeted_attack import dfda_function as df
from tqdm import tqdm
import copy
import matplotlib.pyplot as plt
from deeprobust.graph.defense import GCN

class dfda(BaseAttack):
    def __init__(self, model, nnodes=None, attack_structure=True, attack_features=False, device='cpu'):
        super(dfda, self).__init__(model, nnodes, attack_structure=attack_structure, attack_features=attack_features,
                                      device=device)
        self.structure_perturbations = []
        self.feature_perturbations = []
        self.best_wrong_class=0

    def attack(self, features, adj, target_node, n_perturbations, budget, verbose=True, **kwargs):

        if self.nnodes is None:
            self.nnodes = adj.shape[0]

        self.target_node = target_node

        if type(adj) is torch.Tensor:
            self.ori_adj = utils.to_scipy(adj).tolil()
            self.modified_adj = utils.to_scipy(adj).tolil()
            self.ori_features = utils.to_scipy(features).tolil()
            self.modified_features = utils.to_scipy(features).tolil()
        else:
            self.ori_adj = adj.tolil()
            self.modified_adj = adj.tolil()
            self.ori_features = features.tolil()
            self.modified_features = features.tolil()

        ori_adj=copy.deepcopy(self.ori_adj)
        ori_features=copy.deepcopy(self.ori_features)


        attack_features = self.attack_features
        attack_structure = self.attack_structure
        assert n_perturbations > 0, "need at least 1 perturbation"
        assert attack_features or attack_structure, "at least one of structure and feature must be true"

        if verbose:
            print("      ###attack node ID={}###".format(target_node))
            if attack_structure and attack_features:
                print("      ###perform structure and feature attack###")
            elif attack_structure:
                print("      ###only perform structure attack###")
            elif attack_features:
                print("      ###only perform feature attack###")
            print("      ###constraint size: {}###".format(n_perturbations))

        self.surrogate.eval()
        output = self.surrogate.predict()
        probs = torch.exp(output[[target_node]])[0]
        pprobs = probs.detach().cpu().numpy()
        print("      ###black-box query class probability vector：",pprobs,"###")
        target_node_label=pprobs.argmax()
        print("      ###most probable class：",target_node_label,"###")
        cp=copy.deepcopy(pprobs)
        cp[target_node_label]-=1
        best_wrong_class = cp.argmax()
        self.best_wrong_class=best_wrong_class
        print("      ###attack target class：",best_wrong_class,"###")

        self.nfeat=features.shape[1]

        instrum=ng.p.Dict(
            arraya=ng.p.TransitionChoice(range(self.nnodes), repetitions=n_perturbations),
            arrayx=ng.p.TransitionChoice(range(self.nfeat), repetitions=n_perturbations)
        )

        #define constraint
        def constraint(p):
            if attack_structure:
                a = p['arraya']
                collection=[]
                for _ in a:
                    if _ == target_node:
                        return False
                    if _ not in collection:
                        collection.append(_)
                    else:
                        return False

            if attack_features:
                x = p['arrayx']
                collection = []
                for _ in x:
                    if _ not in collection:
                        collection.append(_)
                    else:
                        return False
            return True

        #select DFOer
        #optimizer = ng.optimizers.OnePlusOne(parametrization=instrum, budget=budget, num_workers=3)
        #optimizer = ng.optimizers.DiscreteOnePlusOne(parametrization=instrum, budget=budget, num_workers=3)
        optimizer = ng.optimizers.DoubleFastGADiscreteOnePlusOne(parametrization=instrum, budget=budget, num_workers=3)
        #optimizer = ng.optimizers.DE(parametrization=instrum, budget=budget, num_workers=3)
        #optimizer = ng.optimizers.RandomSearch(parametrization=instrum, budget=budget, num_workers=3)

        optimizer.parametrization.register_cheap_constraint(constraint)
        recommendation = optimizer.provide_recommendation()

        min_losses = []
        with tqdm(total=optimizer.budget) as pbar:
            pbar.close()
            pbar.set_description('processing')

            for i in range(optimizer.budget):
                x1 = optimizer.ask()
                x2 = optimizer.ask()
                x3 = optimizer.ask()

                loss1 = df.dfda_function(x1.value['arraya'], x1.value['arrayx'], ori_adj, ori_features,
                                         target_node, attack_structure, attack_features, best_wrong_class,self.surrogate,target_node_label)
                loss2 = df.dfda_function(x2.value['arraya'], x2.value['arrayx'], ori_adj, ori_features,
                                         target_node, attack_structure, attack_features, best_wrong_class,self.surrogate,target_node_label)
                loss3 = df.dfda_function(x3.value['arraya'], x3.value['arrayx'], ori_adj, ori_features,
                                         target_node, attack_structure, attack_features, best_wrong_class,self.surrogate,target_node_label)

                optimizer.tell(x1, loss1)
                optimizer.tell(x2, loss2)
                optimizer.tell(x3, loss3)
                min_losses.append(min(loss1,loss2,loss3))
                pbar.update(1)

        plt.xlabel("iter")
        plt.ylabel("loss")
        plt.title("No." + str(target_node) + " target node attack loss")
        plt.plot(min_losses)
        plt.show()
        recommendation = optimizer.provide_recommendation()

        self.structure_perturbations.append(recommendation.value['arraya'])
        self.feature_perturbations.append(recommendation.value['arrayx'])

        #final perturbation
        if attack_structure:
            pert_edges = []
            for _ in recommendation.value['arraya']:
                pert_edges.append((target_node, _))
            print("      ###final pert edges：", pert_edges)

            for edge in pert_edges:
                self.modified_adj[edge] = self.modified_adj[edge[::-1]] = 1 - self.modified_adj[edge]

        if attack_features:
            pert_features = []
            for _ in recommendation.value['arrayx']:
                pert_features.append((target_node, _))
            print("      ###final pert features：", pert_features)

            for feature in pert_features:
                self.modified_features[feature] = 1 - self.modified_features[feature]
